#define RANDOMLIB_VERSION_STRING "1.10"
#define RANDOMLIB_VERSION_MAJOR 1
#define RANDOMLIB_VERSION_MINOR 10
#define RANDOMLIB_VERSION_PATCH 0

// Define HAVE_SSE2 to be 1 if Intel/AMD CPU with SSE2 support
/* #undef HAVE_SSE2 */

// Define HAVE_ALTIVEC to be 1 if Power PC CPU with AltiVec support
/* #undef HAVE_ALTIVEC */

// Undefine HAVE_LONG_DOUBLE if this type is unknown to the compiler
#define HAVE_LONG_DOUBLE 1
