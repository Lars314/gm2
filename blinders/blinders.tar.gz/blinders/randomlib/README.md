RandomLib is copied from Charles Karney's MIT/X11-licensed library.  The original readme is 00README.txt, and it starts at the top with this:

A random number library using the Mersenne Twister random number
generator.

Written by Charles Karney <charles@karney.com> and licensed under
the MIT/X11 License.  For more information, see

    http://randomlib.sourceforge.net/

